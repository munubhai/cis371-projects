// Import the functions you need from the SDKs you need

import { initializeApp } from "firebase/app";
import { getFirestore, Firestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use

// https://firebase.google.com/docs/web/setup#available-libraries


// Your web app's Firebase configuration

const firebaseConfig = {

  apiKey: "AIzaSyBc1DzyJkoxf7RiyvGrB7Dbseu1OpsEPTw",

  authDomain: "project-4-643f1.firebaseapp.com",

  projectId: "project-4-643f1",

  storageBucket: "project-4-643f1.appspot.com",

  messagingSenderId: "363939978137",

  appId: "1:363939978137:web:0e8797f6999c824ebad108"

};

// Initialize Firebase

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

export {firebaseConfig, app};